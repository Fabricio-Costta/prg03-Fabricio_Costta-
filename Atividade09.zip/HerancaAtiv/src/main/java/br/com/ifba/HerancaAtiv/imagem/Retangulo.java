/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fabri
 */
package br.com.ifba.HerancaAtiv.imagem;

public class Retangulo extends Forma {
    private float lado;
    private float altura;

    // Construtor
    public Retangulo(float lado, float altura) {
        this.lado = lado;
        this.altura = altura;
    }

    // Getters e Setters
    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    // Implementação dos métodos da interface Forma
    @Override
    public float calcularArea() {
        return lado * altura;
    }

    @Override
    public float calcularPerimetro() {
        return 2 * (lado + altura);
    }
}

