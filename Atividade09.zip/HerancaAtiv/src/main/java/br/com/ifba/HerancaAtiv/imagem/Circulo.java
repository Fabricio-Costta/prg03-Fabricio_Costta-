/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fabri
 */
package br.com.ifba.HerancaAtiv.imagem;

public class Circulo extends Forma {
    private float raio;

    // Construtor
    public Circulo(float raio) {
        this.raio = raio;
    }

    // Getters e Setters
    public float getRaio() {
        return raio;
    }

    public void setRaio(float raio) {
        this.raio = raio;
    }

    // Método para obter o diâmetro do círculo
    public float calcularDiametro() {
        return 2 * raio;
    }

    // Implementação dos métodos da interface Forma
    @Override
    public float calcularArea() {
        return (float) (Math.PI * raio * raio);
    }

    @Override
    public float calcularPerimetro() {
        return (float) (2 * Math.PI * raio);
    }
}
