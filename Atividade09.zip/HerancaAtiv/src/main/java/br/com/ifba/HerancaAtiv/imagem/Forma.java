/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.com.ifba.HerancaAtiv.imagem;

public abstract class Forma {
    public abstract float calcularArea();
    public abstract float calcularPerimetro();
}


