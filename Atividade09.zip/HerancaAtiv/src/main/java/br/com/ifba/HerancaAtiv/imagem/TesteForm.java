/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fabri
 */
package br.com.ifba.HerancaAtiv.imagem;

public class TesteForm {
    public static void main(String[] args) {
        // criando um vetor com 5 elementos do tipo Forma
        Forma[] formas = new Forma[5];

        // Instanciando objetos de Retangulo, Circulo e Quadrado e armazenando no vetor
        formas[0] = new Retangulo(4, 5);
        formas[1] = new Circulo(3);
        formas[2] = new Quadrado(2);
        formas[3] = new Retangulo(2, 3);
        formas[4] = new Circulo(5);

        // Loop para percorrer o vetor de Forma e invocar os métodos calcularArea() e calcularPerimetro()
        for (Forma forma : formas) {
            System.out.println("Tipo da forma: " + forma.getClass().getSimpleName());
            System.out.println("Área: " + forma.calcularArea());
            System.out.println("Perímetro: " + forma.calcularPerimetro());
            System.out.println();
        }
    }
}

