
import br.com.ifba.animal.imagem.Animal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fabri
 */
// Ave class
public class Ave extends Animal {
    // Specific attribute for Ave
    private String corPena;

    // Constructor
    public Ave(float peso, int idade, int membros, String corPena) {
        super(peso, idade, membros);
        this.corPena = corPena;
    }

    // Overridden method for locomover
    @Override
    public void locomover() {
        System.out.println("Voando");
    }

    // Overridden method for alimentar
    @Override
    public void alimentar() {
        System.out.println("Comendo frutas");
    }

    // Overridden method for emitirSom
    @Override
    public void emitirSom() {
        System.out.println("Som de ave");
    }

    // Method specific to Ave
    public void fazerNinho() {
        System.out.println("Construindo um ninho");
    }
}
