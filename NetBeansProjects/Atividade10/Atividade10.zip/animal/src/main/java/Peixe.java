
import br.com.ifba.animal.imagem.Animal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fabri
 */
public class Peixe extends Animal {
    // Specific attribute for Peixe
    private String corEscama;

    // Constructor
    public Peixe(float peso, int idade, int membros, String corEscama) {
        super(peso, idade, membros);
        this.corEscama = corEscama;
    }

    // Overridden method for locomover
    @Override
    public void locomover() {
        System.out.println("Nadando");
    }

    // Overridden method for alimentar
    @Override
    public void alimentar() {
        System.out.println("Comendo substâncias");
    }

    // Overridden method for emitirSom
    @Override
    public void emitirSom() {
        System.out.println("Peixe não faz som");
    }

    // Method specific to Peixe
    public void soltarBolhar() {
        System.out.println("Soltando bolhas");
    }
}