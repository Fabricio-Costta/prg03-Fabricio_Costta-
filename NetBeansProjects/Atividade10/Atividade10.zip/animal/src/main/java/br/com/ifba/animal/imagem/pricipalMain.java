
package br.com.ifba.animal.imagem;

public class pricipalMain {
    public static void main(String[] args) {
        Mamifero m = new Mamifero(70.5f, 5, 4, 'F');
        Peixe p = new Peixe(0.60f, 3, 4, "Azul");
        Ave a = new Ave(0.60f, 1, 2, "Branca");

        m.locomover(); // correndo
        m.alimentar(); // mamando
        m.emitirSom(); // som de mamifero

        p.locomover(); // nadando
        p.alimentar(); // comendo substancias
        p.emitirSom(); // peixe nao faz son
        p.soltarBolhas(); // soltando bolhas

        a.locomover(); // voando
        a.alimentar(); // comendo frutas
        a.emitirSom(); // som de ave
        a.fazerNinho(); // construindo um ninho
    }
}
