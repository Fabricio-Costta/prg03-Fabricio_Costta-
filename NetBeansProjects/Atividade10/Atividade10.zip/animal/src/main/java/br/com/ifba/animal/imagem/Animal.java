package br.com.ifba.animal.imagem;

/**
 * Abstract class representing an animal.
 */
public abstract class Animal {
    // Attributes
    private float peso;
    private int idade;
    private int membros;

    // Constructor
    public Animal(float peso, int idade, int membros) {
        this.peso = peso;
        this.idade = idade;
        this.membros = membros;
    }

    // Abstract methods (to be implemented by subclasses)
    public abstract void locomover();
    public abstract void alimentar();
    public abstract void emitirSom();

    // Getters and setters
    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getMembros() {
        return membros;
    }

    public void setMembros(int membros) {
        this.membros = membros;
    }
}

