
import br.com.ifba.animal.imagem.Animal;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author fabri
 */
public class Mamifero extends Animal {
    // Attribute specific to Mamifero
    private char corpoPelo;

    // Constructor
    public Mamifero(float peso, int idade, int membros, char corpoPelo) {
        super(peso, idade, membros);
        this.corpoPelo = corpoPelo;
    }

    // Overridden method for locomover
    @Override
    public void locomover() {
        System.out.println("Correndo");
    }

    // Overridden method for alimentar
    @Override
    public void alimentar() {
        System.out.println("Mamando");
    }

    // Overridden method for emitirSom
    @Override
    public void emitirSom() {
        System.out.println("Som de mamífero");
    }
}
